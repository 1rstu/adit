<?php return array (
  'domain' => 'homepage',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
    '' => 
    array (
      'Free, Open Source content management system' => 'Gratis, Open Source sistem manajemen konten',
      'Download' => 'Unduh',
      'Documentation' => 'Dokumentasi',
      'News' => 'Berita',
      'Features' => 'Fitur',
      'Responsive Layout' => 'Tata Letak Responsif',
      'Your site will appear equally well on both computers and mobile devices.' => 'Situs anda akan muncul sama dengan baik pada kedua komputer dan perangkat mobile.',
      'Template System' => 'Sistem Template',
      'Using templates, you can completely change the style of your site so that it becomes unique and not like the others.' => 'Dengan menggunakan template, anda dapat benar-benar mengubah gaya dari situs anda sehingga menjadi unik dan tidak seperti yang lain.',
      'High Performance' => 'Kinerja Tinggi',
      'When developing JohnCMS we pay special attention to system performance.<br>Your website will not require a powerful server for as long as possible.' => 'Ketika mengembangkan JohnCMS kami membayar perhatian khusus untuk kinerja sistem.<br>website Anda tidak akan memerlukan sebuah server yang kuat untuk selama mungkin.',
      'Multilingual' => 'Multibahasa',
      'Reach the maximum audience in different languages. Several languages have already been built into the system.<br>And if you don\'t have the desired language, you can easily add it using advanced translation tools that support johnCMS.' => 'Mencapai maksimum penonton dalam bahasa yang berbeda. Beberapa bahasa yang telah dibangun ke dalam sistem.<br>Dan jika anda tidak memiliki bahasa yang diinginkan, anda dapat dengan mudah menambahkannya canggih menggunakan alat terjemahan yang mendukung johnCMS.',
      'Modularity' => 'Modularitas',
      'The most popular modules are built into the system.<br>You can install ready-made additional modules, create them yourself or order development of new modules from other developers.' => 'Modul yang paling populer yang dibangun ke dalam sistem.<br>Anda dapat menginstal siap pakai modul tambahan, membuat mereka sendiri atau rangka pengembangan modul baru dari pengembang lain.',
      'Free License' => 'Lisensi Gratis',
      'The GNU GPL-3 license gives you the right to distribute and modify JohnCMS.' => 'GNU GPL-3 lisensi ini memberi anda hak untuk mendistribusikan dan memodifikasi JohnCMS.',
    ),
  ),
);