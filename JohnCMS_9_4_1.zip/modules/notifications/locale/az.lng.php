<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Bildiriş silinəcək!',
      'Users on registration' => 'Qeydiyyatlı istifadəçilər',
      'Articles on moderation' => 'Məqalələr moderatsiya',
      'Downloads on moderation' => 'Yuklmeme moderatsiya',
      'Ban' => 'Ban',
      'New forum posts' => 'Forumdakı sonuncu xeberler',
      'Mail' => 'Mesaj',
      'Guestbook' => 'Qonaq Otaqı',
      'Comments' => 'Şərhlər',
      'Settings' => 'Düzəlişlər',
      'Settings saved!' => 'Düzəlişlər yadda saxlanıldı',
      'Notifications' => 'Bildirişlər',
      'All notifications have already been read' => 'Bildirişlər artıq oxunub arxive daxil olun tekrar üçün',
      'Total' => 'Ümumi',
      'Clear notifications' => 'Bildirişləri təmizlə',
      'Display the number of unread messages in the forum' => 'Ekran sayının oxunmamış mesaj, forumda',
      'Save' => 'Yadda saxla',
      'Cancel' => 'Ləğv Et',
    ),
  ),
);