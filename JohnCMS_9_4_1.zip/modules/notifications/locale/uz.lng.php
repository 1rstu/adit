<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=2; plural=(n > 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Ogohlantirishlar tozalandi!',
      'Users on registration' => 'Ro\'yxatga olish bo\'yicha foydalanuvchilar',
      'Articles on moderation' => 'Tekshiruvdagi maqolalar',
      'Downloads on moderation' => 'Tekshiruvdagi yuklamalar',
      'Ban' => 'Bloklash',
      'New forum posts' => 'Forumdagi yangi xabarlar',
      'Mail' => 'Xabar',
      'Guestbook' => 'Mehmonxona',
      'Comments' => 'Sharxlar',
      'Settings' => 'Sozlovlar',
      'Settings saved!' => 'Sozlamalar saqlandi!',
      'Notifications' => 'Bildirishnoma',
      'All notifications have already been read' => 'Yangi bildirishnomalar yo‘q',
      'Total' => 'Jami',
      'Clear notifications' => 'Bildirishnomani tozalash.',
      'Display the number of unread messages in the forum' => 'Forumda o\'qilmagan xabarlar',
      'Save' => 'Saqlash',
      'Cancel' => 'Bekor qilish',
    ),
  ),
);