<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Thành viên',
      'History' => 'Lịch sử',
      'Guests' => 'Khách',
      'IP Activity' => 'Hoạt động IP',
      'Guest' => 'Khách',
      'Who is online?' => 'Ai đang trực tuyến?',
      'Online' => 'Trực tuyến',
      'For registered users only' => 'Chỉ dành cho thành viên đã đăng ký',
      'List is empty' => 'Danh sách trống',
      'Total' => 'Tổng số',
    ),
  ),
);