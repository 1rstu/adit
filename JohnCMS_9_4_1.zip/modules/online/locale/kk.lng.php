<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Қолданушылар',
      'History' => 'Тарих',
      'Guests' => 'Қонақтар',
      'IP Activity' => 'Белсенді IP',
      'Guest' => 'Қонақ',
      'Who is online?' => 'Кім желіде?',
      'Online' => 'Онлайн',
      'For registered users only' => 'Тек қана тіркелген қолданушылар үшін',
      'List is empty' => 'Тізім бос',
      'Total' => 'Барлығы',
    ),
  ),
);