<?php return array (
  'domain' => 'news',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
    '' => 
    array (
      'News' => 'Berita',
      'Text' => 'Isi',
      'Save' => 'Simpan',
      'Do you really want to delete?' => 'Apakah Anda ingin menghapus ini?',
      'Delete' => 'Hapus',
      'Cancel' => 'Batal',
      'Edit' => 'Sunting',
      'Title' => 'Judul',
    ),
  ),
);