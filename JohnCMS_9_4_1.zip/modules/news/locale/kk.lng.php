<?php return array (
  'domain' => 'news',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'News' => 'Жаңалықтар',
      'Text' => 'Мәтін',
      'Save' => 'Сақтау',
      'Do you really want to delete?' => 'Сіз шынымен жойғыңыз келеді ме?',
      'Delete' => 'Жою',
      'Cancel' => 'Бас тарту',
      'Edit' => 'Өзгерту',
      'Title' => 'Тақырып',
    ),
  ),
);