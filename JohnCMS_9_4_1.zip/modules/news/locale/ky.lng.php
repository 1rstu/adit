<?php return array (
  'domain' => 'news',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'News' => 'Жаңылыктар',
      'Text' => 'Текст',
      'Save' => 'Сактоо',
      'Do you really want to delete?' => 'Сиз чын эле өчүрүп таштайсызбы?',
      'Delete' => 'Өчүрүү',
      'Cancel' => 'Токтотуу',
      'Edit' => 'Оңдоо',
      'Title' => 'Аталышы',
    ),
  ),
);