<?php return array (
  'domain' => 'news',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
    '' => 
    array (
      'News' => 'Tin tức',
      'Text' => 'Văn bản',
      'Save' => 'Lưu',
      'Do you really want to delete?' => 'Bạn có thực sự muốn xóa?',
      'Delete' => 'Xóa',
      'Cancel' => 'Hủy bỏ',
      'Edit' => 'Chỉnh sửa',
      'Title' => 'Tiêu đề',
    ),
  ),
);