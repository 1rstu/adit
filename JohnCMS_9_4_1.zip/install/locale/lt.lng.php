<?php return array (
  'domain' => 'install',
  'plural-forms' => 'nplurals=4; plural=(n%10==1 && (n%100>19 || n%100<11) ? 0 : (n%10>=2 && n%10<=9) && (n%100>19 || n%100<11) ? 1 : n%1!=0 ? 2: 3);',
  'messages' => 
  array (
    '' => 
    array (
      'Preparing for installation' => 'Ruošiama diegti',
      'Checking parameters' => 'Parametru tikrinimas',
      'Database' => 'Duomenu baze',
      'Setting' => 'Nustatymai',
      'Completion' => 'Baigimas',
      'PHP version' => 'PHP versija',
      'The PHP version must be at least %s' => 'PHP versija turi buti ne mazesnia nei ',
      'Yes' => 'Taip',
      'No' => 'Ne',
      'PHP extension PDO must be installed' => 'PDO turi buti irasyta',
      'Imagick or GD extension' => 'Imagick arba GD',
    ),
  ),
);