<?php return array (
  'domain' => 'install',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
  ),
);